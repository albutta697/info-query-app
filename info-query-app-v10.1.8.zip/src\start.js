// 启动脚本
console.log('正在启动应用...');
require('./main/main.js'); 