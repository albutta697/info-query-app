// 由于我们已经在main.js中设置了contextIsolation: false，
// 这个preload脚本当前只是一个占位符，以便将来扩展功能。
// 如果将来启用contextIsolation，可以在这里添加contextBridge代码。

console.log('预加载脚本已加载'); 